package common;

import common.driver.Browsers;
import common.driver.Driver;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



/**
 * base class contains wrappers written over selenium methods to reduce future maintenance
 * and increase the reusability of the code.
 */
public class WebElementBase {
    /**
     * usually when page reload, application need to be monitored for possible errors.
     * after every click , automatic verification is done for possible errors
     * @param element - name of the element that need to be clicked
     */
    public void clickElement(WebElement element){
        this.waitForWebElement(element,60);
        element.click();
        String [] errors = {"Error occurred","Environment is down for Maintenance", "Page Not Found"};
        for (String error : errors){
            if (Driver.getInstance(Browsers.Chrome).getPageSource().contains(error)){
                Assert.assertEquals("Error Found on Page",false,false);
            }
        }
    }

    /**
     * Writes text in Text box but clears first
     * reduces clear call made at every box
     * @param element
     * @param value
     */
    public void enterText(WebElement element, String value){
        element.clear();
        element.sendKeys(value);
    }

    /**
     * wrapper to find element using CSS Selector
     * waits before finding an element
     * @param cssSelector - String for element properties
     * @param timeout - when no such element should trigger
     * @return - webelement
     */
    public WebElement findElementByCSS(String cssSelector, int timeout){
        this.waitForWebElement(cssSelector,timeout);
        return Driver.getInstance(Browsers.Chrome).findElement(By.cssSelector(cssSelector));
    }

    /**
     * a common piece of code waits for every element to be clickable
     * @param cssSelector - String for element properties
     * @param timeout - when no such element should trigger
     */
    public void waitForWebElement(String cssSelector, int timeout){
        WebDriverWait wait = new WebDriverWait(Driver.getInstance(Browsers.Chrome),timeout);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(cssSelector)));
    }
    /**
     * Dynamic Polymorphism method to wait for an element
     * @param element
     * @param timeout - when no such element should trigger
     */
    public void waitForWebElement(WebElement element, int timeout){
        WebDriverWait wait = new WebDriverWait(Driver.getInstance(Browsers.Chrome),timeout);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }
    /**
     * selects value from Dropdown
     * @param element
     * @param option
     */
    public void selectValueFromDropdown(WebElement element, String option){
        Select dropDown = new Select(element);
        dropDown.selectByVisibleText(option);
    }

    /**
     * get Titles of the page
     * @return string
     */
    public String getTitle(){
        return Driver.getInstance(Browsers.Chrome).getTitle();
    }


}
