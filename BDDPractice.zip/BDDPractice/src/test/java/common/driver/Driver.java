package common.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

/**
 * Driver intitiation would be taken by this class
 * designed using singleton design pattern to avid multiple objects of the driver but its thread safe
 */
public class Driver {


        private static WebDriver driver = null;

        private Driver(){

        }

        /**
         * use this static method to get the instance of Web driver.
         *
         * @param browser - supply an enum of Browsers
         */
        public static WebDriver getInstance(Browsers browser){
              if (null == driver){
                      synchronized (Driver.class){
                              if (null == driver){
                                switch (browser){
                                        case Chrome:
                                        System.setProperty("webdriver.chrome.driver","C:\\drivers\\chrome\\chromedriver.exe");
                                        driver = new ChromeDriver();
                                        break;
                                        case IE:
                                        driver = new InternetExplorerDriver();
                                        System.setProperty("webdriver.chrome.driver","C:\\drivers\\chrome\\chromedriver.exe");
                                        break;
                                        case Firefox:
                                        System.setProperty("webdriver.firefox.driver","C:\\drivers\\chrome\\chromedriver.exe");
                                        driver = new FirefoxDriver();
                                        break;
                                        default:
                                        System.out.print("Requested browser is not supported");
                                        break;
                                }
                              }
                      }
              }
            return driver;
        }

}
