package common.driver;

public enum Browsers {
    Chrome,
    IE,
    Firefox;
}
