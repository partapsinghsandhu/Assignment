package pageaccessor.web;

import org.openqa.selenium.WebDriver;

public class PageObjectManager {
    WebDriver driver;
    Index index;
    Reserve reserve;
    Purchase purchase;
    Confirmation confirmation;

    public PageObjectManager(WebDriver driver){
        this.driver = driver;
    }

    /**
     * returns object for Index page
     * @return index page
     */
    public Index getIndexPage(){
        if (null == index){
            index = new Index();
        }
        return index;
    }

    /**
     * returns object for Reserve page
     * @return reserve page
     */
    public Reserve getReservePage(){
        if ( null == reserve){
            reserve = new Reserve();
        }
        return reserve;
    }

    /**
     * returns object for Purchase page
     * @return purchase page
     */
    public Purchase getPurchasePage(){
        if ( null == purchase){
            this.purchase = new Purchase();
        }
        return purchase;
    }

    /**
     * returns object for Confirmation Page
     * @return confirmation page
     */
    public Confirmation getConfirmationPage(){
        if ( null == confirmation){
            this.confirmation = new Confirmation();
        }
        return confirmation;
    }
}
