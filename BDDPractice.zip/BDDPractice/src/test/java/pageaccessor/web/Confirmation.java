package pageaccessor.web;

import common.WebElementBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class Confirmation extends WebElementBase {

//region properties
    private WebElement getConfirmationTableElement(){
        return this.findElementByCSS(".table",60);
    }
//endregion
//region public methods

    /**
     * using java 8 lambda expression, method gets all Tds and validate if td next to id contains value and
     * if yes, then validates its size. Currently system generates 13 digit id so validating accordingly.
     * @return true / false
     */
    public Boolean isConfirmationIdFound(){
        List<String> entireTDs =  this.getConfirmationTableElement().findElements(By.cssSelector("td")).
                stream().map(WebElement::getText)
                .collect(Collectors.toList());
        String confirmId = null;
        for(int i = 0; i <entireTDs.size(); i ++){
           if (entireTDs.get(i).equals("Id")){
               confirmId =  entireTDs.get(i + 1);
               break;
           }
        }
        // As confirmation id is generated on random basis so we cant match with expected condition
        // but still we can validate its size between given numbers to have best match.

        if (null != confirmId ){
            if(confirmId.length() >= 10 && confirmId.length() <= 14){
                return true;
            }
        }
        return false;
    }
//endregion
}
