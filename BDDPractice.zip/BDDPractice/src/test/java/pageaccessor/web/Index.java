package pageaccessor.web;

import common.WebElementBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Index extends WebElementBase {
    WebDriver driver;
//region constructors

//endregion

//region properties
    private WebElement getFromPortSelectElement(){
        return this.findElementByCSS("select[name*='fromPort']",60);
    }
    private WebElement getToPortSelectElement(){
        return this.findElementByCSS("select[name*='toPort']",60);
    }
    private WebElement getFindFlightButtonElement(){
        return this.findElementByCSS(".btn.btn-primary",60);
    }
//endregion

//region public methods

    /**
     * select Departure City
     * @param departureCity - name of the departure city
     */
    public void selectDepartureCity(String departureCity){
        this.selectValueFromDropdown(this.getFromPortSelectElement(),departureCity);
    }

    /**
     * select Destination City
     * @param destinationCity - name of the destination city
     */
    public void selectDestinationCity(String destinationCity){
        this.selectValueFromDropdown(this.getToPortSelectElement(),destinationCity);
    }

    /**
     * clicks on Find flight button
     */
    public void clickFindFlightButton(){
        this.clickElement(this.getFindFlightButtonElement());
    }


//endregion

}
