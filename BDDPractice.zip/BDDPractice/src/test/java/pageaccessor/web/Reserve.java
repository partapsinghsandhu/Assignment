package pageaccessor.web;

import common.WebElementBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class Reserve extends WebElementBase {
//region properties
    private WebElement getChooseFlightTableElement(){
        return this.findElementByCSS(".table",60);
    }

//endregion

//region public methods

    /**
     * choose flight based upon flight # , Airline, Time, Price etc.
     * @param flightDetailsToChoose
     * @return Purchase object
     */
    public void chooseFlight(String flightDetailsToChoose){
    this.waitForWebElement(".btn.btn-small",60);
        List<WebElement>  elements = this.getChooseFlightTableElement().findElements(By.cssSelector("tr td"));
            for (WebElement element : elements){
                if (element.getText().contains(flightDetailsToChoose)){
                    this.clickElement(element.findElement(By.xpath("..")).findElement(By.cssSelector(".btn.btn-small")));
                }
            }
          }

    /**
     * if element displayed or not
     * @return
     */
    public Boolean isChooseFlightButtonDisplayed(){
        return this.getChooseFlightTableElement().isDisplayed();
    }

//endregion
}
