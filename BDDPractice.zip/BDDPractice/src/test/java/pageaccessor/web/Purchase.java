package pageaccessor.web;

import common.WebElementBase;
import org.openqa.selenium.WebElement;


public class Purchase extends WebElementBase {

//region properties
    private WebElement getPurchaseFlightButtonElement(){
        return this.findElementByCSS(".btn.btn-primary",60);
    }
    private WebElement getNameTextBoxElement(){
        return this.findElementByCSS("input[id*='inputName']",60);
    }
    private WebElement getAddressTextBoxElement(){
        return this.findElementByCSS("input[id*='address']",60);
    }
    private WebElement getCityTextBoxElement(){
        return this.findElementByCSS("input[id*='city']",60);
    }
    private WebElement getStateTextBoxElement(){
        return this.findElementByCSS("input[id*='state']",60);
    }
    private WebElement getZipCodeTextBoxElement(){
        return this.findElementByCSS("input[id*='zipCode']",60);
    }
    private WebElement getCardTypeDropdownElement(){
        return this.findElementByCSS("select[id*='cardType']",60);
    }
    private WebElement getCreditCardNumberTextBoxElement(){
        return this.findElementByCSS("input[id*='creditCardNumber']",60);
    }
    private WebElement getCreditCardMonthTextBoxElement(){
        return this.findElementByCSS("input[id*='creditCardMonth']",60);
    }
    private WebElement getCreditCardYearTextBoxElement(){
        return this.findElementByCSS("input[id*='creditCardYear']",60);
    }
    private WebElement getNameOnCreditCardTextBoxElement(){
        return this.findElementByCSS("input[id*='nameOnCard']",60);
    }

//endregion

//region public methods

    public void enterName(String name){
        this.enterText(this.getNameTextBoxElement(),name);
    }
    public void enterAddress(String address){
        this.enterText(this.getAddressTextBoxElement(),address);
    }
    public void enterCity(String city){
        this.enterText(this.getCityTextBoxElement(),city);
    }
    public void enterState(String state){
        this.enterText(this.getStateTextBoxElement(),state);
    }
    public void enterZipCode(String zipCode){
        this.enterText(this.getZipCodeTextBoxElement(),zipCode);
    }
    public void selectCardType(String cardType){
        this.selectValueFromDropdown(this.getCardTypeDropdownElement(),cardType);
    }
    public void enterCreditCardNumber(String creditCardNumber){
        this.enterText(this.getCreditCardNumberTextBoxElement(),creditCardNumber);
    }
    public void enterCreditCardMonth(String creditCardMonth){
        this.enterText(this.getCreditCardMonthTextBoxElement(),creditCardMonth);
    }
    public void enterCreditCardYear(String creditCardYear){
        this.enterText(this.getCreditCardYearTextBoxElement(),creditCardYear);
    }
    public void enterNameOnCreditCard(String nameOnCreditCard){
        this.enterText(this.getNameOnCreditCardTextBoxElement(),nameOnCreditCard);
    }

    /**
     * clicks Purchase Flight Button
     */
    public void clickPurchaseFlightButton(){
        this.clickElement(this.getPurchaseFlightButtonElement());
    }
    /**
     * if purchase flight Button displayed or not
     * @return true / false
     */
    public Boolean isPurchaseFlightButtonDisplayed(){
        return this.getPurchaseFlightButtonElement().isDisplayed();
    }

//endregion
}
