package StepDef.rest;


import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;

public class SpaceXStepDef {

    private RequestSpecification request ;
    private Response response;
    @Before
    @Given("Rest Assured object is created")
    public void createRestAssuredObject() {
            if (null == request){
                request = RestAssured.given();
            }
    }
    @Before
    @When("User hit get service")
    public void callGetService() {
        response = request.get("https://api.spacexdata.com/v4/launches/latest");
    }

    @Then("Validate response code")
    public void validateResponseCode() {
        Assert.assertEquals("Response Code should be 200",
        200,response.getStatusCode());
        response.getSessionId();
    }

    @Then("Validate Ships number")
    public void validateShipsNumber() {
        Assert.assertEquals("Match Ships Id",
        true,response.getBody().asString().contains("6059166413f40e27e8af34b6"));

    }

    @Then("Validate response time should be within SLA")
    public void validateResponseTimeShouldBeWithinSLA() {
        Boolean withInSLA = false;
        if(response.getTime() <= 9000){
            withInSLA = true;
        }
        Assert.assertEquals("Response Time should be within SLA",
                true,withInSLA);
    }

}
