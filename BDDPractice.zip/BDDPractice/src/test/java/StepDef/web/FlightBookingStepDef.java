package StepDef.web;

import common.driver.Browsers;
import common.driver.Driver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import pageaccessor.web.*;

public class FlightBookingStepDef {
    PageObjectManager pageObjectManager;
    WebDriver driver = Driver.getInstance(Browsers.Chrome);
    Index index;
    Reserve reserve;
    Purchase purchase;
    Confirmation confirmation;

    @Given("Initiate Object Manager")
    public void Initiate_Object_Manager(){
        pageObjectManager = new PageObjectManager(driver);
       this.index = pageObjectManager.getIndexPage();
        this.reserve = pageObjectManager.getReservePage();
        this.purchase = pageObjectManager.getPurchasePage();
        this.confirmation = pageObjectManager.getConfirmationPage();
    }

    @Given("user is at flight search page")
    public void userIsAtFlightSearchPage() {
        driver.get("https://blazedemo.com/index.php");
        Assert.assertEquals("Verify if user is at valid page","BlazeDemo", index.getTitle());
    }

    @When("user selects departure city")
    public void userSelectsDepartureCity() {
        index.selectDepartureCity("Portland");
    }

    @And("user selects destination city")
    public void userSelectsDestinationCity() {
        index.selectDestinationCity("Rome");
    }

    @And("user clicks on find flight button")
    public void userClicksOnFindFlightButton() {
       index.clickFindFlightButton();
    }

    @Then("user should be landed to Reserve Page to choose flight")
    public void userShouldBeLandedToReservePageToChooseFlight() {
        Assert.assertEquals("Is choose Flight Button Displayed",
        true,reserve.isChooseFlightButtonDisplayed());
    }

    @Given("user is at Reserve flight page")
    public void userIsAtReserveFlightPage() {
        Assert.assertEquals("Verify if user is navigated to Reserve Page",
                "BlazeDemo - reserve", reserve.getTitle());
    }

    @When("user clicks choose flight button")
    public void userClicksChooseFlightButton() {
      reserve.chooseFlight("234");
    }

    @Then("user should be landed to Purchase Page To make Payment")
    public void userShouldBeLandedToPurchasePageToMakePayment() {
        Assert.assertEquals("Is Purchase Flight Button Displayed",
                true,purchase.isPurchaseFlightButtonDisplayed());
    }

    @Given("user is at Purchase flight page")
    public void userIsAtPurchaseFlightPage() {
        Assert.assertEquals("Verify if user is navigated to Reserve Page",
                "BlazeDemo Purchase", purchase.getTitle());
    }

    @When("user enters name")
    public void userEntersName() {
        purchase.enterName("Partap Singh Sandhu");
    }

    @And("user enters address")
    public void userEntersAddress() {
        purchase.enterAddress("VV Puram Road");
    }

    @And("user enters city")
    public void userEntersCity() {
        purchase.enterCity("Bangalore");
    }

    @And("user enters state")
    public void userEntersState() {
        purchase.enterState("karnataka");
    }

    @And("user enters zip code")
    public void userEntersZipCode() {
        purchase.enterZipCode("560018");
    }

    @And("user selects card type")
    public void userSelectsCardType() {
        purchase.selectCardType("Visa");
    }

    @And("user enters credit card number")
    public void userEntersCreditCardNumber() {
        purchase.enterCreditCardNumber("123456789");
    }

    @And("user enters month")
    public void userEntersMonth() {
        purchase.enterCreditCardMonth("10");
    }

    @And("user enters year")
    public void userEntersYear() {
        purchase.enterCreditCardYear("2023");
    }

    @And("user enters name on card")
    public void userEntersNameOnCard() {
        purchase.enterNameOnCreditCard("Partap");
    }

    @And("user clicks on Purchase Flight")
    public void userClicksOnPurchaseFlight() {
        purchase.clickPurchaseFlightButton();
    }

    @Then("user should be able to get Confirmation Id")
    public void userShouldBeAbleToGetConfirmationId() {
        Assert.assertEquals("Verify if confirmation id generated",true, confirmation.isConfirmationIdFound());
    }
}
