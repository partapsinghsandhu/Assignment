package runner;

import common.driver.Browsers;
import common.driver.Driver;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"src\\test\\java\\feature\\web"},glue = {"StepDef\\web"}, plugin = { "pretty","html:target/report" },
        monochrome = true)
public class TestRunner {
    @AfterClass
    public static void rampDown(){
        Driver.getInstance(Browsers.Chrome).close();
        Driver.getInstance(Browsers.Chrome).quit();
    }
}
