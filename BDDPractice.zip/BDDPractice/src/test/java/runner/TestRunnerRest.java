package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"src\\test\\java\\feature\\services\\rest"},glue = {"StepDef\\rest"}, plugin = { "pretty","html:target/report" },
        monochrome = true)
public class TestRunnerRest {
    @AfterClass
    public static void rampDown(){
    }
}
